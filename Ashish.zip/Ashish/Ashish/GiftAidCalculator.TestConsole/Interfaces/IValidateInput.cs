﻿namespace GiftAidCalculator.TestConsole.Interfaces
{
    public interface IValidateInput
    {
        bool IsInputValid();
    }
}