﻿namespace GiftAidCalculator.TestConsole.Interfaces
{
    public interface ICalculateGiftAid
    {
        decimal GiftAidAmount(decimal donationAmount);
    }
}