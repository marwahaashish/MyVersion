﻿namespace GiftAidCalculator.TestConsole.Interfaces
{
    public interface ITaxRateRepository
    {
        decimal TaxRate { get;set; }
    }
}